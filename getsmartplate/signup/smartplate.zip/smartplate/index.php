<?php
$notified_msg = '';
$error_msg = '';

if(isset($_POST['data_capture_form'])){
	$pattern = '/^(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){255,})(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){65,}@)(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22))(?:\\.(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-+[a-z0-9]+)*\\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-+[a-z0-9]+)*)|(?:\\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\\]))$/iD';

	if (preg_match($pattern, $_POST['email']) === 1) {
		
	}else{
		$error_msg = "EmailAddress is not valid";
	}
	
	if(!empty($error_msg)){
		$notified_msg = $error_msg;
	}else{
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "smartplate";
	$email_message = "";
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}else{
		if (!empty($_SERVER['HTTP_CLIENT_IP'])){
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}else{
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		//$curnt_date = date('Y-m-d H:i:s');
		$sql = "INSERT INTO data_capture(fname, lname, email, create_date, ip_address) VALUES ('".$_POST['fname']."', '".$_POST['lname']."', '".$_POST['email']."', now(), '".$ip."')"; 
		if (mysqli_query($conn, $sql)){		
			// php mail script start
			$email_to = "chetan.dignitas@gmail.com"; 
			$email_subject = "Email from SmartPlate"; 
			
			$email_message .= "First Name: ".$_POST['fname']."\n"; 
			$email_message .= "Last Name: ".$_POST['lname']."\n"; 
			$email_message .= "Email: ".$_POST['email']."\n"; 
			
			// create email headers 
			$headers = 'From: '.$_POST['email']."\r\n".	 
			'Reply-To: '.$_POST['email']."\r\n" .	 
			'X-Mailer: PHP/' . phpversion();	 
			@mail($email_to, $email_subject, $email_message, $headers); 
			// php mail script end
			
			$notified_msg = "Thank you for showing interest in SmartPlate. We will keep you posted with the latest updates.";	
		}else{
			$notified_msg = "Thank you for showing interest in SmartPlate. We will keep you posted with the latest updates.";
		}	
		mysqli_close($conn);

	}
}}

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Smart Plate</title>
<link href="style.css" rel="stylesheet" type="text/css">

</head>

<body>
	<div id="container">
   	  <div class="header">
       <div class="logo"><img src="images/logo.png"alt=""/></div>
      </div>
      <div class="header-slide">
      	<div><img src="images/header.jpg" alt=""/></div>
        <div class="headingtext">
        <h1><span>Eating</span> smart is about to get</h1>
        <h2>a whole lot smarter.</h2>
        </div>
      </div>
      <div class="body-container">
      		<h1>We are launching soon.</h1>
            <h2>Please enter your email to stay tuned.</h2>
        <div class="form">
		<span><?php echo $notified_msg; ?></span>
		<form action="index.php" name="data_capture" id="data_capture" method="post">
			<div class="input-div"><input type="text" placeholder="First Name" name="fname" required /></div>        
			<div class="input-div"><input type="text" placeholder="Last Name" name="lname" required /></div>
			<div class="input-div"><input type="email" placeholder="Email" name="email" required /></div>
			<div class="submit-btn"><input type="submit" name="data_capture_form" id="data_capture_form" value="SUBMIT"</div>
		</form>	
        </div>
    </div>
      </div>
      </div>
      

</body>
</html>
